const crypto = require('crypto');

function generateHash(word) {
    if (!word) {
        return "";
    }
    return crypto.createHash('sha256').update(word).digest('hex');
}

module.exports = {
    generateHash
};
