const { Router } = require('express');
const router = Router();
const { generateHash } = require('../utils/hashGenerator');

router.get('/:word', (req, res) => {
    const { word } = req.params;

    const hashResult = generateHash(word);

    res.json({
        "status": "success",
        "original_word": word,
        "hash_sha256": hashResult,
        "environment": "Dockerized Node.js Environment"
    });
});

module.exports = router;
