const express = require('express');
const morgan = require('morgan');
const routes = require('./routes');

const app = express();

app.set('port', process.env.PORT || 3000);

app.use(morgan('dev'));
app.use(express.json());

app.use('/generateHash', routes);

module.exports = app;
