const app = require('./app');

async function main() {
    const port = app.get('port');
    await app.listen(port);
    console.log(`=========================================`);
    console.log(`Servidor de Hashes iniciado correctamente`);
    console.log(`Escuchando en el puerto local: ${port}`);
    console.log(`=========================================`);
}

main();
